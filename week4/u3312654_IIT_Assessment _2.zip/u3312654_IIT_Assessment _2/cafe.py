''' NAME= Bhawesh Rijal
    STUDENT ID= u3312654
    DATE= 16/09/2025 
     '''
#AVAILABLE ITEMS
menu_items={
    "latte": {"price":2.50, "category":"Drink"},
    "coffee": {"price":1.50, "category":"Drink"},
    "tea": {"price":1.00, "category":"Drink"},
    "burger": {"price":5.50, "category":"Food"},
    "muffin": {"price":4.50, "category":"Food"},
    }
shopping_cart=[] #list of tuples

#functions
# Show the cafe menu with items, prices, and categories
def display_menu():
    print("\n cafe menu")
    print("{:<12} {:>7} {:>10}".format("Item","Price","Category"))
    print("-"*32)
    for item_name, details in menu_items.items():
        print("{:<12} ${:>6.2f} {:>10}". format(item_name, details["price"], details["category"]))


# Add an item to the shopping cart
def add_to_cart(cart):
    item_name=input("enter item name: ").lower()
    if item_name not in menu_items:
        print("item not available. please choose available items:", ", ".join(menu_items.keys())) #This line is refined using GenAI
        return
    try:
        quantity=int(input("enter the quantity"))
        if (quantity<=0):
            print("enter a positive quantity")
            return
    except ValueError:
        print("please enter a whole number")
        return
    cart.append((item_name, quantity))
    print(f"ADDED items: {quantity} * {item_name} to cart")



# Show all items currently in the cart
def view_cart(cart):
    if not cart:
        print("No items added in the cart")
        return
    print("\ncart contents")
    print("{:<12} {:>5} {:>10}".format("Item","QTY","Unit Price"))
    print("-"*33)
    for item_name, quantity in cart:
        unit_price=menu_items[item_name]["price"]
        print("{:<12} {:>5} ${:>9.2f}". format(item_name, quantity, unit_price))


# Print final receipt with discounts and tax
def calculate_receipt(cart):
    subtotal=0.0
    item_categories=set()
    print("\nReceipt")
    print("{:<12} {:>5} {:>10} {:>12}".format("Item", "QTY","Unit price"," Line Total"))
    print("-"*50)

    #Caluculate the line total
    for item_name, quantity in cart:
        unit_price=menu_items[item_name]["price"]
        category=menu_items[item_name]["category"]
        item_categories.add(category)
        line_total=quantity * unit_price
        print("{:<12} {:>5} ${:>10.2f} ${:>12.2f}".format(item_name,quantity,unit_price, line_total))
        subtotal=subtotal+line_total
    print(f"Subtotal before discounts: ${subtotal:,.2f}") # this line was refined using GenAI

        
        #streach feature: meal deal if customer purchases both food and drink
    if "Food" in item_categories and "Drink" in item_categories:
        print(" Discount applied: -$3.00")
        subtotal=subtotal-3.00
        print(f"subtotal: {subtotal:,.2f}")
    tax_amount=subtotal* 0.10
    total_amount= subtotal+tax_amount
    
    
        #student discount: 5%
    is_student=input("Are you a student (y/n)? ").strip().lower().startswith("y")
    if is_student:
        total_amount=total_amount*0.95
        print("student discount applied (5%)")
    print("-"*50)
    print(f"subtotal: ${subtotal:,.2f}")
    print(f"Tax (10%): ${tax_amount:,.2f}")
    print(f"Total:  ${total_amount:,.2f}")
    
    # streach feature: unique categories
    print("\n categories in cart:",",".join(sorted(item_categories)))


# main program loop  
print("campus cafe POS")
print("1. show menu")
print("2.ADD item")
print("3. view cart")
print("4. checkout")
print("5. Exit")
while True:    
    user_choice=input("choose an option (1-5): ").strip()  
    if user_choice=="1":
        display_menu()
    elif user_choice=="2":
        add_to_cart(shopping_cart)
    elif user_choice=="3":
        view_cart(shopping_cart)
    elif user_choice=="4":
        calculate_receipt(shopping_cart)
    elif user_choice=="5":
        print("Thankyou for visiting our cafe")
        break
    else:
        print("invalid choice. please enter from 1 to 5")
        
                
        
    
                        
                     
        
