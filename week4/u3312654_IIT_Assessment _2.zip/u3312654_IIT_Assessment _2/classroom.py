''' NAME= Bhawesh Rijal
    STUDENT ID= u3312654
    DATE= 16/09/2025 
'''
# --- Functions ---
action_log = []

# Save what action happened
def log_action(action):
    action_log.append(action)
    print("(Logged) ", action)

# Switch projector ON/OFF
def toggle_projector(status):
    status = not status
    msg = f"Projector turned {'ON' if status else 'OFF'}"
    return status, msg

# Set the classroom topic
def set_topic(topic):
    msg = f"Topic set to {topic}"
    return topic, msg


# Add a student if room not full
def add_student(attendance, capacity, name):
    if len(attendance) >= capacity:
        return attendance, "ROOM FULL"
    attendance.add(name)
    return attendance, f"{name} added to attendance"

# Remove a student if present
def remove_student(attendance, name):
    if name in attendance:
        attendance.remove(name)
        return attendance, f"{name} removed from attendance"
    return attendance, f"{name} not found in attendance"


# Record a new temperature and warn if out of safe range
def add_temp(temp_log, temp):
    temp_log.append(temp)
    alert = ""
    if temp < 16 or temp > 28:
        alert = "Warning: Temperature out of range!"
    return temp_log, f"Temperature {temp}°C added. {alert}"


# Get lowest, highest, and average temperature
def temp_stats(temp_log):
    if not temp_log:
        return None, None, None
    return min(temp_log), max(temp_log), sum(temp_log)/len(temp_log)


# Show classroom report such as projector, topic, attendance, temperature, and alerts
def report(room, attendance, temp_log):
    min_t, max_t, avg_t = temp_stats(temp_log)
    alert_msg = ""
    if len(attendance) > room["capacity"]:
        alert_msg += "ROOM FULL\n"
    if room["topic"] and not room["projector_on"]:
        alert_msg += "Reminder: Turn on projector\n"
    if min_t is not None and (min_t < 16 or max_t > 28):
        alert_msg += "Warning: Temperature out of range\n"
    print("\n--- Classroom Report ---")
    print(f"Projector: {'ON' if room['projector_on'] else 'OFF'}")
    print(f"Topic: {room['topic']}")
    print(f"Attendance ({len(attendance)}/{room['capacity']}): {', '.join(attendance)}")
    if min_t is not None:
        print(f"Temperature - Min: {min_t}°C, Max: {max_t}°C, Avg: {avg_t:.2f}°C")
    # suggested by GenAI
    if alert_msg:
        print("\nAlerts:")
    for alert in alert_msg.strip().split("\n"):
        print(f" - {alert}")

        
# class room attributes
room = {"projector_on": False, "capacity": 5, "topic": ""}
attendance = set()
temp_log = []

# Ask if projector should be toggled
while True:
    projector = input("Do you want to toggle the projector? (y/n): ").lower()

    if projector.startswith("y"):
        room["projector_on"], msg = toggle_projector(room["projector_on"])
        log_action(msg)
        break
    elif projector.startswith("n"):
        log_action(f"Projector remains {'ON' if room['projector_on'] else 'OFF'}")
    else:
        print("Invalid input. Enter y, n, or done.")


# Ask for the topic of the class
topic_input = input("Enter topic: ")
room["topic"], msg = set_topic(topic_input)
log_action(msg)

# Add Students to attendence
while True:
    name = input("Enter student name to add (or 'done' to finish): ")
    if name.lower() == "done":
        break
    # Validation: prevent blank names, suggested by GenAI
    if not name:
        print("Name cannot be empty.")
        continue
    # Validation: prevent duplicates, suggested by GenAI
    if name in attendance:
        print(f"{name} is already in attendance.")
        continue
    attendance, msg = add_student(attendance, room["capacity"], name)
    log_action(msg)

# Remove Students from attendance
while True:
    name = input("Enter student name to remove (or 'done' to finish): ")
    if name.lower() == "done":
        break
    attendance, msg = remove_student(attendance, name)
    log_action(msg)


#  Record the classroom temperature readings
while True:
    temp_input = input("Enter temperature (°C) (or 'done'): ")
    if temp_input.lower() == "done":
        break
    try:
        temp_val = float(temp_input)
        # Validate temperature range,  suggested by GenAI
        if not (10 <= temp_val <= 40):
            print("Please enter a temperature between 10°C and 40°C.")
            continue
        temp_log, msg = add_temp(temp_log, temp_val)
        log_action(msg)
    except ValueError:
        print("Invalid number.")

# Report
report(room, attendance, temp_log)

# show all the actions taken (stretch feature)
print("\n--- Action Log (Stretch Feature) ---")
for entry in action_log:
    print(entry)
    
