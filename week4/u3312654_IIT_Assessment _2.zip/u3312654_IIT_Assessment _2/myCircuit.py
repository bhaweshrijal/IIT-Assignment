''' NAME= Bhawesh Rijal
    STUDENT ID= u3312654
    DATE= 16/09/2025 
'''

# Circuit implementations
# calculates the output (X) of circuit (a)
def circuit_a(A, B, C):
    X = (not B and (A or C) and A) or (A and B and C)
    return int(X)

# calculates the output(Y) of circuit (b)
def circuit_b(A, B, C):
    Y = (A and ((not B) or C))
    return int(Y)

# Input loop
print("Enter values for A, B, and C (0 or 1). Type 'exit' to quit.\n")

while True:
        A_input = input("Enter A (0 or 1): ").strip()
        if A_input.lower() == "exit":
            break
        B_input = input("Enter B (0 or 1): ").strip()
        if B_input.lower() == "exit":
            break
        C_input = input("Enter C (0 or 1): ").strip()
        if C_input.lower() == "exit":
            break

        # Validate inputs
        if A_input not in ["0", "1"] or B_input not in ["0", "1"] or C_input not in ["0", "1"]:
            print("Invalid input. Please enter only 0 or 1 only.\n")
            continue

        A = int(A_input)
        B = int(B_input)
        C = int(C_input)

        # Compute outputs
        X = circuit_a(A, B, C)
        Y = circuit_b(A, B, C)

        # Display results
        print(f"\nInputs: A={A}, B={B}, C={C}")
        print(f"Output X (Circuit A): {X}")
        print(f"Output Y (Circuit B): {Y}")
        if X == Y:
            print("Outputs match: circuits are equivalent for this input.\n")
        else:
            print("Outputs does not match: circuits are NOT equivalent for this input.\n")
